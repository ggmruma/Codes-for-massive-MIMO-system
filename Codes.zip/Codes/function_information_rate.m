% cost function
function Rate = function_information_rate(H, P, Ns, FRFO, WRFO)
 
 FBBO = 1.299*eye(Ns);

 WBBO = eye(Ns);
 
 Rate = log2(det(eye(Ns) + P/Ns * pinv(WRFO * WBBO) * H * FRFO * (FBBO) * FBBO' * FRFO' * H' * WRFO * WBBO));

end