% cost function
function Rate = function_information_rate(H, P, Ns, FRFO, WRFO)

 [~,nt] = size(H);
 if nt == 64
 FBBO = 1.299*eye(Ns);
 else
  alpha = 1 + (2-1)*rand(1);
  FBBO = alpha*eye(Ns);
 end
 
 WBBO = eye(Ns);
 
 Rate = log2(det(eye(Ns) + P/Ns * pinv(WRFO * WBBO) * H * FRFO * (FBBO) * FBBO' * FRFO' * H' * WRFO * WBBO));

end