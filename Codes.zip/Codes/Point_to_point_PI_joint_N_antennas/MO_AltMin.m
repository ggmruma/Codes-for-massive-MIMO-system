function [ FRF,FBB, flop_c ] = MO_AltMin( Fopt, NRF,H )

flop_c = 0;
[Nr, ~] = size(H);
[Nt, Ns, K] = size(Fopt);
y = [];
flop_c = flop_c + 4*Nt^2*Nr + 8*Nt*Nr^2 + 9*Nr^3;
FRF = exp( 1i*unifrnd(0,2*pi,Nt,NRF) );
while(isempty(y) || abs(y(1)-y(2))>1e-1)
    y = [0,0];
    for k = 1:K      
        FBB(:,:,k) = pinv(FRF) * Fopt(:,:,k); 
        y(1) = y(1) + norm(Fopt(:,:,k) - FRF * FBB(:,:,k),'fro')^2;
        flop_c = flop_c + NRF^3 + NRF^2 + NRF + 4*Nt*NRF*Ns - 2*Nt*Ns ...
            + 2*Nt*NRF*Ns + Nt*Ns + NRF*Ns - 1;
    end
    [FRF, y(2), flop] = sig_manif(Fopt, FRF, FBB);
    flop_c = flop_c + flop;
end

end