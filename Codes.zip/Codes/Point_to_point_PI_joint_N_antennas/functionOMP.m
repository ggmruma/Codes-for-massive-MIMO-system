function [ FRF, FBB, Sol_ind, flop_c] = functionOMP( Fopt,Ns, NRF, At, H )

[Nr,Nt] = size(H);
[~,L] = size(At);
flop_c = 0;
flop_c = flop_c + 4*Nt^2*Nr + 8*Nt*Nr^2 + 9*Nr^3;
FRF = [];
Fres = Fopt;
Sol_ind = zeros(1,NRF);
for i = 1:NRF
    
    
     PU = At' * Fres;
    
    [~,bb] = max(diag( PU*PU'));
    
   
    FRF = [FRF , At(:,bb)];
    Sol_ind(i) = bb;
    
    FBB = pinv(FRF) * Fopt;
    Fres = (Fopt - FRF * FBB) / norm(Fopt - FRF * FBB,'fro');
    % Computational complexity
    flop_c = flop_c + L*Ns*(2*Nt - 1) + L*(2*Ns - 1) ...
        + 4*Nt*i + i^3 + 2*Nt*Ns*i + i - Nt*i - Ns*i ...
        + 3*Nt*Ns + Nt - 1 + 2*Nt*NRF*Ns + Nt*Ns + NRF*Ns - 1;
    
end
   FBB = sqrt(Ns)*(FBB/norm(FRF*FBB,'fro'));
end