% simulator for different number of antennas
clear all;
clc;

Nc = 5; % # of clusters
Nray = 10; % # of rays in each cluster

Nt = [64, 144, 256, 529]; % # of transmit antennas
nNt = length(Nt);
Nr = 16; % # of receive antennas
Ns = 3; % # of streams
NRF = 3;


angle_sigma = 10/180*pi; %standard deviation of the angles in azimuth and elevation both of Rx and Tx


sigma = 1; %according to the normalization condition of the H

SNR_dB = -10;
SNR = 10^(SNR_dB/10);


Chare = 1000;   % number of channel realization

RateOpt = zeros(nNt,Chare);
RateOMP = zeros(nNt,Chare); 
RateMoALt = zeros(nNt,Chare); 
Rate_TS = zeros(nNt,Chare);

FLOP_OMP = zeros(nNt,Chare);
FLOP_MoALt = zeros(nNt,Chare);
FLOP_TS = zeros(nNt,Chare);

for iNt = 1:nNt
    P = SNR;
    for iCh = 1: Chare
        gamma = sqrt((Nt(iNt)*Nr)/(Nc*Nray)); %normalization factor
        [H,At,Ar] = ChannelModel(Nr,Nt(iNt),gamma,sigma,Nc,Nray,angle_sigma);
        
        % optimal precoder svd based
            [U,S,V] = svd(H);
            Fopt = V([1:Nt(iNt)],[1:Ns]);
            Wopt = U([1:Nr],[1:Ns]);
            RateOpt(iNt,iCh) = log2(det(eye(Ns) + P/Ns * pinv(Wopt) * H * (Fopt) * Fopt' * H' * Wopt));
            
        % OMP Algorithm precoder
           [FRFO, FBBO, ~, flop_ot ] = functionOMP( Fopt,Ns, NRF, At, H);
           FBBO = sqrt(Ns) * FBBO / norm(FRFO * FBBO,'fro');
            
        % OMP Algorithm combiner 
           [WRFO, WBBO,~ ,flop_or] = functionOMPSPMMSE(H,FRFO,FBBO,Ar,Ns,P);
           RateOMP(iNt,iCh) = log2(det(eye(Ns) + P/Ns * pinv(WRFO * WBBO) * H * FRFO * (FBBO) * FBBO' * FRFO' * H' * WRFO * WBBO));
           FLOP_OMP(iNt,iCh) = flop_ot + flop_or;
    
         % MO-ALT Precoder
         [ FRF,FBB , flop_t] = MO_AltMin( Fopt, NRF,H );
         
         % MO-ALT Combiner
         [ WRF,WBB, flop_r ] = MO_AltMin( Wopt, NRF, H );
         RateMoALt(iNt,iCh) = log2(det(eye(Ns) + P/Ns * pinv(WRF * WBB) * H * FRF * (FBB) * FBB' * FRF' * H' * WRF * WBB)); 
         FLOP_MoALt(iNt,iCh) = flop_t + flop_r;
           
           
        % Proposed TS based algorithm
          [Rate_TS(iNt,iCh), flop_ts] = functionTS_IP_ET_TX_TX(H,P,Ns,At,Ar,NRF,P,Fopt);
          
              
           FLOP_TS(iNt,iCh) = flop_ts;
        
    end
 iNt
end
R_D = abs(mean( RateOpt,2));
R_PS = abs(mean(RateOMP,2));
Rate_MoALt = abs(mean(RateMoALt,2));
Rate_TS_PI = abs(mean(Rate_TS,2));

Flop_OMP = mean(FLOP_OMP,2);
Flop_MoALt = mean(FLOP_MoALt,2);
Flop_TS_PI = mean(FLOP_TS,2);

LineWidth = 1.8;
MarkerSize = 7;

figure(1)
plot(Nt, R_D, 'Color',[1 0.2 0.2], 'LineWidth', LineWidth, 'Marker','o',...
     'LineStyle','-','MarkerSize',MarkerSize)
 
 hold on
 plot(Nt,R_PS , 'Color',[0.6350 0.0780 0.1840], 'LineWidth', LineWidth, 'Marker','+',...
     'LineStyle','--','MarkerSize',MarkerSize)
 
 hold on
 plot(Nt,Rate_MoALt , 'Color',[0.4 0.4 0.4], 'LineWidth', LineWidth, 'Marker','p',...
      'LineStyle','-','MarkerSize',MarkerSize)
  
 hold on
   plot(Nt,Rate_TS_PI , 'Color',[0 0.4 0.6897], 'LineWidth', LineWidth, 'Marker','+',...
      'LineStyle','-.','MarkerSize',MarkerSize)
 hold off
 
 legend('SVD optimal','OMP','MoAlt','Proposed TS - ET','Location', 'NorthWest')
 xlabel('Number of antennas')
 ylabel('Spectral Efficiency [bps/Hz]')
 xlim([64 529]);
 set(gca,'XTick',Nt );
 grid on
 
 [EE_D, EE_PS,EE_MoAlt, EE_PI] = functionEEdifferentNt(Nt,Nr,NRF,R_D,R_PS, Rate_TS_PI,Rate_MoALt);
 
 figure (2)
 plot(Nt, EE_D, 'Color',[1 0.2 0.2], 'LineWidth', LineWidth, 'Marker','o',...
     'LineStyle','-','MarkerSize',MarkerSize)
 hold on
 plot(Nt, EE_PS, 'Color',[0.6350 0.0780 0.1840], 'LineWidth', LineWidth, 'Marker','+',...
     'LineStyle','--','MarkerSize',MarkerSize)
  hold on
   hold on
 plot(Nt,EE_MoAlt , 'Color',[0.4 0.4 0.4], 'LineWidth', LineWidth, 'Marker','p',...
      'LineStyle','-','MarkerSize',MarkerSize)
   hold on
 plot(Nt, EE_PI, 'Color',[0 0.4 0.6897], 'LineWidth', LineWidth, 'Marker','+',...
     'LineStyle','-.','MarkerSize',MarkerSize)
 hold off
 
 legend('SVD optimal','OMP','MoAlt','Proposed TS - ET','Location', 'NorthEast')
 xlabel('Number of antennas')
 ylabel('Energy efficiency [bps/Hz/W]')
  xlim([64 529]);
 set(gca,'XTick',Nt );
 grid on
 
 figure(3)
  semilogy(Nt, Flop_OMP, 'Color',[0.6350 0.0780 0.1840], 'LineWidth', LineWidth, 'Marker','+',...
     'LineStyle','--','MarkerSize',MarkerSize)

   hold on
 semilogy(Nt,Flop_MoALt , 'Color',[0.4 0.4 0.4], 'LineWidth', LineWidth, 'Marker','p',...
      'LineStyle','-','MarkerSize',MarkerSize)
   hold on
 semilogy(Nt, Flop_TS_PI, 'Color',[0 0.4 0.6897], 'LineWidth', LineWidth, 'Marker','+',...
     'LineStyle','-.','MarkerSize',MarkerSize)
 hold off
 
  legend('OMP','MoAlt','Proposed TS - ET','Location', 'NorthWest')
 xlabel('Number of antennas')
 ylabel('Computational complexity')
  xlim([64 529]);
 set(gca,'XTick',Nt );
 grid on