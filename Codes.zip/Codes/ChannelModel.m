function [H,At,Ar] = ChannelModel(Nr,Nt,gamma,sigma,Nc,Nray,angle_sigma)

    AoD = zeros(2,Nray);
    AoA = zeros(2,Nray);
    Ht = zeros(Nr,Nt,Nc);
    H = zeros(Nr,Nt);
    At = zeros(Nt,Nc*Nray);
    Ar = zeros(Nr,Nc*Nray);
   
    
    for c = 1:Nc
        AoD_m = unifrnd(0,2*pi,1,2);
        AoA_m = unifrnd(0,2*pi,1,2);
        
        AoD(1,:) = laprnd(1,Nray,AoD_m(1),angle_sigma);
        AoD(2,:) = laprnd(1,Nray,AoD_m(2),angle_sigma);
        AoA(1,:) = laprnd(1,Nray,AoA_m(1),angle_sigma);
        AoA(2,:) = laprnd(1,Nray,AoA_m(2),angle_sigma);
        
%         Ht(:,:,c) = zeros(Nr,Nt);
        for j = 1:Nray
            temp = (c-1)*Nray+j;
            At(:,temp) = array_response(AoD(1,j),AoD(2,j),Nt);
            Ar(:,temp) = array_response(AoA(1,j),AoA(2,j),Nr);
            alpha = normrnd(0,sqrt(sigma/2)) + 1i*normrnd(0,sqrt(sigma/2));
            Ht(:,:,c) = Ht(:,:,c) + alpha * Ar(:,temp) * At(:,temp)';
        end
    end
    
   
%         H(:,:,k) = zeros(Nr,Nt);
        for c = 1:Nc
            H(:,:) = H(:,:) + Ht(:,:,c);
        end
        H(:,:) = H(:,:) * gamma;
        
end  % end of the function
        
  