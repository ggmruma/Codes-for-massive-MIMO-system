% cost function
function Rate = function_information_rate_1(H, P, Ns, F, W)

 Rate = log2(det(eye(Ns) + P/Ns * pinv(W) * H * (F)* F' * H' * W));
 


end