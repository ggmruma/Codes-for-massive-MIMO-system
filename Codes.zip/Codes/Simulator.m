%Author: Godwin Mruma Gadiel
% This code simulate the results for the manuscript "Energy Efficient Phase
% Interpolator based Hybrid beamforming Architecture for massive MIMO
% system.

clear all;
clc;

Nc = 5; % # of clusters
Nray = 10; % # of rays in each cluster

Nt = 144; % # of transmit antennas
Nr = 36; % # of receive antennas
Ns = 3; % # of streams
NRF = 3;


angle_sigma = 10/180*pi; %standard deviation of the angles in azimuth and elevation both of Rx and Tx

gamma = sqrt((Nt*Nr)/(Nc*Nray)); %normalization factor
sigma = 1; %according to the normalization condition of the H

SNR_dB = -10:5:10;
 


Chare = 1000;   % number of channel realization

iSNR = length(SNR_dB);

RateOpt = zeros(iSNR,Chare);
Rate_TS = zeros(iSNR,Chare);
Rate_OMP = zeros(iSNR,Chare);
Rate_ALT = zeros(iSNR,Chare);

for in = 1:iSNR
    P = 10^(SNR_dB(in)/10);
    for iCh = 1: Chare

        [H,PathG,At,Ar] = ChannelModel1(Nr,Nt,gamma,sigma,Nc,Nray,angle_sigma); % channel generator
        
        % optimal precoder svd based
            [U,S,V] = svd(H);
            Fopt = V([1:Nt],[1:Ns]);
            Wopt = U([1:Nr],[1:Ns]);
            RateOpt(in,iCh) = log2(det(eye(Ns) + P/Ns * pinv(Wopt) * H * (Fopt) * Fopt' * H' * Wopt));
            
         % OMP algorithm
          [FRF_OMP, FBB_OMP] = functionOMP( Fopt,Ns, NRF, At );  % the transmitter part
          [WRF_OMP, WBB_OMP] = functionOMPSPMMSE(H,FRF_OMP, FBB_OMP,Ar,Ns,P); % the receiver part
          Rate_OMP(in,iCh) = log2(det(eye(Ns) + P/Ns * pinv(WRF_OMP * WBB_OMP) * H * FRF_OMP * (FBB_OMP) * FBB_OMP' * FRF_OMP' * H' * WRF_OMP * WBB_OMP));
           
          %MoAlT optimization method
           [FRF_Alt,FBB_Alt]  = MO_AltMin( Fopt, NRF ); % the transmitter side
           [WRF_Alt,WBB_Alt]  = MO_AltMin( Wopt, NRF ); % the receiver side
           Rate_ALT(in,iCh) = log2(det(eye(Ns) + P/Ns * pinv(WRF_Alt * WBB_Alt) * H * FRF_Alt * (FBB_Alt) * FBB_Alt' * FRF_Alt' * H' * WRF_Alt * WBB_Alt));

        % Proposed precoder and combiner
        [R_TS] = functionTS_IP_ET_TX_TX(H,P,Ns,At,Ar);
        Rate_TS(in,iCh) = R_TS; 
        
        
    end
 in
end

LineWidth = 1.8;
MarkerSize = 7;

figure(1)

plot(SNR,abs(mean( RateOpt,2)), 'Color',[1 0.2 0.2], 'LineWidth', LineWidth, 'Marker','none',...
     'LineStyle','-','MarkerSize',MarkerSize)
 
 hold on
 
 plot(SNR,abs(mean( Rate_OMP,2)), 'Color',[05 0.2 0.2], 'LineWidth', LineWidth, 'Marker','x',...
     'LineStyle','--','MarkerSize',MarkerSize)
 hold on
 
 plot(SNR,abs(mean( Rate_ALT,2)), 'Color',[0.4 0.4 0.4], 'LineWidth', LineWidth, 'Marker','*',...
     'LineStyle','-','MarkerSize',MarkerSize)
 hold on

  plot(SNR, abs(mean( Rate_TS,2)), 'Color',[0 0.4 0.6897],'LineWidth', LineWidth, 'Marker','+',...
      'LineStyle','-.','MarkerSize',MarkerSize)

 hold off
 legend('SVD optimal','OMP','MoAlt','Proposed - TS - ET','Location', 'SouthWest')
 xlabel('SNR [dB]')
 ylabel('Spectral Efficiency [bps/Hz]')
  
 grid on
 
