% generate solution probabilistically
function RB = function_solgen_in(N,M)

P = 0.3;
%N = 80;
%M = 4;

RBS = rand(1,N) < P ;  
% will give roughly a proportion of P ones among N values
% exactly M ones among N values
RBS = false(1,N) ;
RBS(1:M) = true ; 

%RBS = RBS(randperm(numel(RBS)
RBS = RBS(randperm(numel(RBS)));
[~, RB]= find(RBS);



end