% spartially sparse combining using MMSE 
function [W_RF, W_BB, Sol_ind] = functionOMPSPMMSE(H,F_RF, F_BB,Ar,Ns,SNR)
[Nr,~] = size(H);
Sol_ind = zeros(1,Ns);
% Rx (Spatially sparse MMSE combining, using OMP)
        W_MMSE = (1/sqrt(SNR) * inv(F_BB'*F_RF'*H'*H*F_RF*F_BB + Ns/SNR*eye(Ns))*F_BB'*F_RF'*H')'; % rx, mmse
        W_RF = []; % empty matrix
        W_res = W_MMSE;
        Eyy = (SNR/Ns*H*F_RF*F_BB*F_BB'*F_RF'*H' + eye(Nr));
        for i=1:Ns %NRFr
            Psi = Ar'*Eyy*W_res;
            [~,k] = max(diag(Psi*Psi'));
            W_RF = [W_RF Ar(:,k)];
            Sol_ind(i) = k;
            W_BB = inv(W_RF'*Eyy*W_RF)*W_RF'*Eyy*W_MMSE;
            W_res = (W_MMSE - W_RF * W_BB)/norm(W_MMSE - W_RF * W_BB,'fro');
        end


end  % end of the function