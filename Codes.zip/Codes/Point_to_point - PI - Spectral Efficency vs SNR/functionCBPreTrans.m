% correlation based precoding selection
function FRF = functionCBPreTrans(PathG,At, NRF,Nc,Nray)

   Nt = size(At,1);
   FRF = zeros(Nt,NRF);
   IN = 1:Nc*Nray;
   Ir = [];
   Tmp = abs(PathG);
   [maxval,~] = max(Tmp(:));
   [row,col] = find(Tmp == maxval);
   Ind = row*col;
  for j = 1:NRF
      Ise = IN(Ind);                              
      IN = [IN(1:Ind-1) IN(Ind+1:end)];       % update the remaining indices in the pool
      Ir = [Ir Ise];                                 % store the removed columns
      CorG = [];
      for i = 1:length(IN)

          CorG(i) = At(:,Ise)'*At(:,IN(i))/(norm(At(:,Ise))*norm(At(IN(i))));
      end

      [~,Ind] = min(CorG);
  end
   FRF = At(:,Ir);
end % end of the functin