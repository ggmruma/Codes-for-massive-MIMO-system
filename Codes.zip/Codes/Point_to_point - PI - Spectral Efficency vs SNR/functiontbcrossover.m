function sel_ch = functiontbcrossover(s, t, L)
N = 2;
G = length(s); %                                          % Chromosome size



x1 = s;                                                           % Parent 1
x2 = t;                                                            % Parent 2

 y = zeros(N,G);


%% 
alpha1=randi([0 1],size(x1));
yc1=alpha1.*x1+(1-alpha1).*x2;
 yc2=alpha1.*x2+(1-alpha1).*x1;
 y(1,:) = yc1;
 y(2,:) = yc2;
%%
%% simple random correction algorithm
for ii = 1:2
    if (nnz(y(ii,:)) == L)
        child(ii,:) = y(ii,:);
    else
        if (nnz(y(ii,:)) > L)       % correcting when number of ones are greater than L
            [rId, cId] = find( y(ii,:) ) ;
            out = randperm(length(cId),(length(cId) - L));  % randomly obtain the indices to be swaped
            for i = 1: length(cId) - L  % randomly flipping ones to zeros
                y(ii,cId(out(i))) = 0;
            end
            child(ii,:) = y(ii, :);
        elseif (nnz(y(ii,:)) < L)   % correctiong when number of ones are less than L
            [zId, zId] = find( ~y(ii,:) ) ;
            q = G - length(zId);
            outz = randperm(length(zId),L-q);  % randomly obtain the indices of zeros to be swaped
            for j = 1: L-q    % randomly flipping zeros to ones
                y(ii,zId(outz(j))) = 1;
            end
            child(ii,:) = y(ii, :);
        end
    end
end
%%
% Selected Child
selch = randi([1 2]);
sel_ch = child(selch,:);

end