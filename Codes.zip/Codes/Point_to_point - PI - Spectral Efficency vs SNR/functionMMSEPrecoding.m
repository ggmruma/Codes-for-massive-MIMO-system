% computing mmse digital precoding
function FBMSE = functionMMSEPrecoding(Heq,F,P,Ns)
  %K = size(Heq,1);

  
  FBMSE = inv(Heq'*Heq + (Ns/P)*eye(Ns))*Heq';
  
  alpha = trace(F'*F*(FBMSE)*FBMSE');
  
  FBMSE = (1/sqrt(alpha))*FBMSE;

end % end of the function