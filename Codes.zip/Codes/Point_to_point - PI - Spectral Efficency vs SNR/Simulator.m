clear all;
clc;

Nc = 5; % # of clusters
Nray = 10; % # of rays in each cluster

Nt = 144; % # of transmit antennas
Nr = 36; % # of receive antennas
Ns = 2; % # of streams
NRF = 6;


angle_sigma = 10/180*pi; %standard deviation of the angles in azimuth and elevation both of Rx and Tx

gamma = sqrt((Nt*Nr)/(Nc*Nray)); %normalization factor
sigma = 1; %according to the normalization condition of the H

SNR_dB = -10:5:10;
SNR = 10.^(SNR_dB./10);  
smax = length(SNR);

Chare = 100;   % number of channel realization

RateOpt = zeros(smax,Chare);
RateOMP = zeros(smax,Chare); 
RateCBS = zeros(smax,Chare);
RateMoALt = zeros(smax,Chare);
Rate_TS = zeros(smax,Chare);

for isnr = 1:smax
    P = SNR(isnr);
    for iCh = 1: Chare

        [H,PathG,At,Ar] = ChannelModel1(Nr,Nt,gamma,sigma,Nc,Nray,angle_sigma);
        
        % optimal precoder svd based
            [U,S,V] = svd(H);
            Fopt = V([1:Nt],[1:Ns]);
            Wopt = U([1:Nr],[1:Ns]);
            RateOpt(isnr,iCh) = log2(det(eye(Ns) + P/Ns * pinv(Wopt) * H * (Fopt) * Fopt' * H' * Wopt));
            
        % OMP Algorithm precoder
           [FRFO, FBBO, Sol_ind_frf] = functionOMP( Fopt,Ns, NRF, At );
           FBBO = sqrt(Ns) * FBBO / norm(FRFO * FBBO,'fro');
            
        % OMP Algorithm combiner 
           [WRFO, WBBO, Sol_ind_wrf] = functionOMPSPMMSE(H,FRFO,FBBO,Ar,Ns,P);
           RateOMP(isnr,iCh) = log2(det(eye(Ns) + P/Ns * pinv(WRFO * WBBO) * H * FRFO * (FBBO) * FBBO' * FRFO' * H' * WRFO * WBBO));
          % RateOMP(isnr,iCh) = log2(det(eye(Ns) + P/Ns * pinv(WRFO) * H * (FRFO) * FRFO' * H' * WRFO));
           
        % Correlation based precoding and combining
           %FRF = functionCBPreTrans(PathG,At, NRF,Nc,Nray);
           %WRF = functionCBPreReceiver(PathG,Ar, NRF,Nc,Nray);
           %RateCBS(isnr,iCh) = log2(det(eye(Ns) + P/Ns * pinv(WRF) * H * (FRF)* FRF' * H' * WRF));
           %RateCBS(isnr,iCh)  = function_information_rate(H, P, Ns, FRF, WRF);
           
         % MO-ALT Precoder
         [ FRF,FBB ] = MO_AltMin( Fopt, NRF );
         
         % MO-ALT Combiner
         [ WRF,WBB ] = MO_AltMin( Wopt, NRF );
          RateMoALt(isnr,iCh) = log2(det(eye(Ns) + P/Ns * pinv(WRF * WBB) * H * FRF * (FBB) * FBB' * FRF' * H' * WRF * WBB)); 

        % Tabu search based selection
        %FRF_TS = functionTS_IP_ET_TX(H,P,Ns,At,Wopt);
        
        %WRF_TS = functionTS_IP_ET_RX(H,P,Ns,FRF_TS,Ar);
        
        [FRF_TS,WRF_TS, RTS] = functionTS_IP_ET_TX_TX(H,P,Ns,At,Ar,NRF,P,Fopt);
        
        Rate_TS(isnr,iCh) = RTS; %function_information_rate(H, P, Ns, FRF_TS, WRF_TS);
        
        warning('off')
    end
 isnr
end

R_D = abs(mean( RateOpt,2));
R_CBS = abs(mean(RateCBS,2));
R_PS = abs(mean(RateOMP,2));
R_MoAlt = abs(mean(RateMoALt,2));
Rate_TS_PI = abs(mean(Rate_TS,2));
% R_MOALT = abs(mean(RateMoALt,2));

LineWidth = 1.8;
MarkerSize = 7;
figure(1)

plot(SNR_dB, R_D, 'Color',[1 0.2 0.2], 'LineWidth', LineWidth, 'Marker','o',...
     'LineStyle','-','MarkerSize',MarkerSize)
 
 hold on
 plot(SNR_dB,R_PS , 'Color',[0.6350 0.0780 0.1840], 'LineWidth', LineWidth, 'Marker','+',...
     'LineStyle','--','MarkerSize',MarkerSize)
 
  hold on
  plot(SNR_dB,R_MoAlt , 'Color',[0.4 0.4 0.4], 'LineWidth', LineWidth, 'Marker','p',...
      'LineStyle','-','MarkerSize',MarkerSize)
 
  hold on
  plot(SNR_dB,Rate_TS_PI , 'Color',[0 0.4 0.6897], 'LineWidth', LineWidth, 'Marker','+',...
      'LineStyle','-.','MarkerSize',MarkerSize)

 hold off
 legend('SVD optimal','OMP','MoAlt ','Proposed - TS - ET','Location', 'NorthWest')
 xlabel('SNR [dB]')
 ylabel('Spectral Efficiency [bps/Hz]')
 set(gca,'XTick',SNR_dB );
 grid on
 
 [EE_D, EE_PS, EE_PI, EE_MoAlt] = functionEEcomputation(Nt,Nr, NRF,R_D,R_PS, Rate_TS_PI,R_MoAlt);
 
 figure(2)
 plot(SNR_dB, EE_D, 'Color',[1 0.2 0.2], 'LineWidth', LineWidth, 'Marker','o',...
     'LineStyle','-','MarkerSize',MarkerSize)
 hold on
 plot(SNR_dB, EE_PS, 'Color',[0.6350 0.0780 0.1840], 'LineWidth', LineWidth, 'Marker','+',...
     'LineStyle','--','MarkerSize',MarkerSize)
 
 hold on
 plot(SNR_dB, EE_MoAlt, 'Color',[0.4 0.4 0.4], 'LineWidth', LineWidth, 'Marker','p',...
     'LineStyle','-','MarkerSize',MarkerSize)
 
  hold on
 plot(SNR_dB, EE_PI, 'Color',[0 0.4 0.6897], 'LineWidth', LineWidth, 'Marker','+',...
     'LineStyle','-.','MarkerSize',MarkerSize)

 hold off
 
 legend('SVD optimal','OMP','MoAlt ','Proposed - TS - ET','Location', 'NorthWest')
 xlabel('SNR [dB]')
 ylabel('Energy efficiency [bps/Hz/W]')
 set(gca,'XTick',SNR_dB );
 grid on