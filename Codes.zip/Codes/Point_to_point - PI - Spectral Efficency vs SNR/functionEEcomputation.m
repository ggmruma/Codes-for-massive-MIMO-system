% function for power consumption computation
function [EE_D, EE_PS, EE_PI, EE_MoAlt] = functionEEcomputation(Nt,Nr,Nrf,R_D,R_PS, R_PI, R_MoAlt)

% power consumption summary
Pref = 20e-3;
Plna = Pref;
Phpa = Pref;
Pps = 1.5*Pref;
Padc = 10*Pref;
Prfc = 2*Pref;
PVGA = 0.6*Pref;
Pbb = Padc;     % assumption by mendez

% Energy efficiency computation for digital architecture
Pdt = Nt*( Prfc + Padc) + Pbb;   % transmitter side
Pdr = Nr*( Prfc + Padc) + Pbb;   % receiver side
EE_D = R_D./(Pdt + Pdr);                

% Energy efficiency computation for full connected phased array
Ppst =  Nt*Nrf*Pps + Nrf*(Prfc + Padc) + Pbb; % tranmitter side
Ppsr =  Nr*Nrf*Pps + Nrf*(Prfc + Padc) + Pbb; % receiver side
EE_PS = R_PS./(Ppst + Ppsr);
EE_MoAlt = R_MoAlt./(Ppst + Ppsr);

% Energy efficiency computation for PI at the transmitter and phase shifter
% at the receiver
PIt =  2*Nrf*Pps + Nrf*(2*Nt - 2)*PVGA + Nrf*(Prfc + Padc) + Pbb;  % tranmitter side
PIr =  2*Nrf*Pps + Nrf*(2*Nr - 2)*PVGA + Nrf*(Prfc + Padc) + Pbb; % receiver side
EE_PI = R_PI./(PIt + PIr);

end  % end of the function