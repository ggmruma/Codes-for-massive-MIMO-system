function [ FRF, FBB, Sol_ind ] = functionOMP( Fopt,Ns, NRF, At )

FRF = [];
Fres = Fopt;
Sol_ind = zeros(1,NRF);
for i = 1:NRF
    
    
     PU = At' * Fres;
    
    [~,bb] = max(diag( PU*PU'));
    
   
    FRF = [FRF , At(:,bb)];
    Sol_ind(i) = bb;
    
    FBB = pinv(FRF) * Fopt;
    Fres = (Fopt - FRF * FBB) / norm(Fopt - FRF * FBB,'fro');
    
end
   FBB = sqrt(Ns)*(FBB/norm(FRF*FBB,'fro'));
end