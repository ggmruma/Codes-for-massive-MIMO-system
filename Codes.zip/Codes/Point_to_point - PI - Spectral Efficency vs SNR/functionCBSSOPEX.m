% CB selection with sub optimal exhaustive search
function Rmax = functionCBSSOPEX(H,PathG,At,Ar,Nc,Nray,NRF,Ns,P)

   IN = 1:Nc*Nray;
   Ir = [];
    %Tmp = abs(PathG);    % in case we use path gain
   Tmp = abs(H*At);     % in case we use correlation
   [maxval,LInd] = max(Tmp(:));
   [row,col] = find(Tmp == maxval);
   %Ind = row*col;        % in case we use path gain
   Ind = col;        % in case we use correlation
  for j = 1:Nc*Nray
      Ise = IN(Ind);                              
      IN = [IN(1:Ind-1) IN(Ind+1:end)];       % update the remaining indices in the pool
      Ir = [Ir Ise];                                 % store the removed columns
      CorG = [];
      for i = 1:length(IN)

          CorG(i) = At(:,Ise)'*At(:,IN(i))/(norm(At(:,Ise))*norm(At(IN(i))));
      end

      [~,Ind] = min(CorG);
  end
  %^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  
  %Receiver codebook selection ^^^^^^^^^^^^^^^^^^^^^^^^^^
   Nr = size(Ar,1);
   WRF = zeros(Nr,NRF);
   IC = 1:Nc*Nray;
   Irc = [];
 % Tmpr = abs(PathG);    % in case we use path gain
   Tmpr = abs(Ar'*H);     % in case we  use correlation
   [max_val,~] = max(Tmpr(:));
   [ror,colr] = find(Tmpr == max_val);
   %Indr = ror*colr;       % in case we use path gain
   Indr = ror;            % in case we use correlation
  for j = 1:Nc*Nray
      Iser = IC(Indr);                              
      IC = [IC(1:Indr-1) IC(Indr+1:end)];       % update the remaining indices in the pool
      Irc = [Irc Iser];                                 % store the removed columns
      CorGr = [];
      for i = 1:length(IC)

          CorGr(i) = Ar(:,Iser)'*Ar(:,IC(i))/(norm(Ar(:,Iser))*norm(Ar(IC(i))));
      end

      [~,Indr] = min(CorGr);
  end
  %^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  
  Tsel = 1:NRF;
  Rsel = 1:NRF;
  Rmax = 0;
  while Tsel(end) ~= Nc*Nray
      FRF = At(:,Ir(Tsel));
      WRF = Ar(:,Irc(Rsel));
      Rate = log2(det(eye(Ns) + P/Ns * pinv(WRF) * H * (FRF)* FRF' * H' * WRF));
      if Rate > Rmax
          Rmax = Rate;
          T_S = Ir(Tsel);
          R_S = Irc(Rsel);
      end
      Tsel(2:end) = Tsel(2:end) + 1;
      Rsel(2:end) = Rsel(2:end) + 1;
  end  % end while
end % end of the function