% correlation based combiner selection
function WRF = functionCBPreReceiver(PathG,Ar, NRF,Nc,Nray)

   Nr = size(Ar,1);
   WRF = zeros(Nr,NRF);
   IC = 1:Nc*Nray;
   Irc = [];
   Tmpr = abs(PathG);
   [max_val,~] = max(Tmpr(:));
   [ror,colr] = find(Tmpr == max_val);
   Indr = ror*colr;
  for j = 1:NRF
      Iser = IC(Indr);                              
      IC = [IC(1:Indr-1) IC(Indr+1:end)];       % update the remaining indices in the pool
      Irc = [Irc Iser];                                 % store the removed columns
      CorGr = [];
      for i = 1:length(IC)

          CorGr(i) = Ar(:,Iser)'*Ar(:,IC(i))/(norm(Ar(:,Iser))*norm(Ar(IC(i))));
      end

      [~,Indr] = min(CorGr);
  end
   WRF = Ar(:,Irc);
end % end of the functin