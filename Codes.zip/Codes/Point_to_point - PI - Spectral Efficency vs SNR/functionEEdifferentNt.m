% function for power consumption computation for different number of
% antenna
function [EE_D, EE_PS, EE_PI] = functionEEdifferentNt(Nt,Nr,Nrf,R_D,R_PS, R_PI)

% power consumption summary
Pref = 20e-3;
Plna = Pref;
Phpa = Pref;
Pps = 1.5*Pref;
Padc = 10*Pref;
Prfc = 2*Pref;
PVGA = 0.6*Pref;
Pbb = Padc;     % assumption by mendez
EE_D = zeros(length(Nt),1);
EE_PS = zeros(length(Nt),1);
EE_PI = zeros(length(Nt),1);


for i = 1:length(Nt)
    % Energy efficiency computation for digital architecture
    Pdt = Nt(i)*( Prfc + Padc) + Pbb;   % transmitter side
    Pdr = Nr*( Prfc + Padc) + Pbb;   % transmitter side
    EE_D(i) = R_D(i)/(Pdt + Pdr);                

    % Energy efficiency computation for full connected phased array
    Ppst = Nt(i)*Nrf*Pps + Nrf*(Prfc + Padc) + Pbb; % tranmitter side
    Ppsr = Nr*Nrf*Pps + Nrf*(Prfc + Padc) + Pbb; % receiver side
    EE_PS(i) = R_PS(i)/(Ppst + Ppsr);

    % Energy efficiency computation for PI at the transmitter and phase shifter
    % at the receiver
    PIt =  2*Nrf*Pps + Nrf*(2*Nt(i) - 2)*PVGA + Nrf*(Prfc + Padc) + Pbb;  % tranmitter side
    PIr =  2*Nrf*Pps +  Nrf*(2*Nr - 2)*PVGA + Nrf*(Prfc + Padc) + Pbb; % receiver side
    EE_PI(i) = R_PI(i)/(PIt + PIr);
end
end  % end of the function