function [WRF] = functionTS_IP_ET_RX(H,P,Ns,FRF,Ar)
% Tabu search algorithm
[~,Nt] = size(H);
[~,N] = size(Ar);

%%% Problem definition
CostFunction = @ function_information_rate;  % Cost Function

%Number of actions is defined by number of antennas
% Note that the total number of action is Nt*U however U times will be
% applied inside the loop
nAction1 = Nt;

%%% Tabu Search Parameters

MaxIt = 60;                      % Maximum Number of Iterations

%TL1 = 5*nAction1;   % in our case we considered the tabu list to be infinity
 
%%% Initialization

% Create Empty Individual Structure
empty_individual.analogPrecoder = [];
empty_individual.Systemrate = [];
empty_individual.SolIndex = [];

% Create Initial Solution
sol = empty_individual;
I_solgen = function_solgen(N,Ns);  % generating initial solution
sol.SolIndex = I_solgen;
sol.ananogPrecoder = Ar(:,sol.SolIndex);
sol.Systemrate = CostFunction(H, P, Ns,FRF,sol.ananogPrecoder);

% Initialize Best Solution Ever Found
BestSol = sol;

% Array to Hold Best Costs
BestCost = zeros(MaxIt,1);

% Initialize Action Tabu Counters
TC = {};


%%% Tabu Search Main Loop
cn = 0;   % initialize counter for early termination
for it =1:MaxIt
    
    bestnewsol.Systemrate = -inf;
    
    % Apply Actions
    for i = 1:nAction1
        I_solgen_new = function_solgen(N,Ns);  % generating solution
        LS = zeros(1,length(TC));
        for k = 1:length(TC)

            LS(k) = sum(ismember(I_solgen_new,TC{k}));
        end
                if ismember(Ns,LS) ~= 1
                    newsol.SolIndex = I_solgen_new;
                    newsol.ananogPrecoder = Ar(:,newsol.SolIndex);
                    newsol.Systemrate = CostFunction(H, P, Ns, FRF,newsol.ananogPrecoder);
                   


                    newsol.ActionIndex = {i};
                else
                    newsol = sol;             % keep the current solution
                    newsol.ActionIndex = {i};
                end

                if newsol.Systemrate  > bestnewsol.Systemrate 
                    bestnewsol = newsol;
                end
            
        
    end
   
    % Update Current Solution
    sol = bestnewsol;
    
    % Update Tabu List*** We assume tabu list is too large and therefore
   TC{i} = bestnewsol.SolIndex;
    % Update Best Solution Ever Found
    if sol.Systemrate > BestSol.Systemrate
        BestSol = sol;
    end
    
    % Save Best Cost Ever Found
    BestCost(it) = BestSol.Systemrate;
      
    
    % early termination
     if it > 1
        if BestCost(it-1) == BestCost(it)
            cn = cn + 1;
            if cn == 4
                break
            end
        else
            cn = 0;
        end
        
    end
    
end  % end of iteration
W = BestSol.SolIndex;  % the best selected indices
WRF = Ar(:,W);  


end% end of the function

