% function for power consumption computation
function [EE_D, EE_PS, EE_PI, EE_MoAlt] = functionEEcomputation_RFChain(Nt,Nr,Nrf,R_D,R_PS, R_PI, R_MoAlt)

% power consumption summary
Pref = 20e-3;
Plna = Pref;
Phpa = Pref;
Pps = 1.5*Pref;
Padc = 10*Pref;
Prfc = 2*Pref;
PVGA = 0.6*Pref;
Pbb = Padc;     % assumption by mendez

EE_PS = zeros(length(Nrf),1);
EE_MoAlt = zeros(length(Nrf),1);
EE_PI = zeros(length(Nrf),1);


% Energy efficiency computation for digital architecture
Pdt = Nt*( Prfc + Padc) + Pbb;   % transmitter side
Pdr = Nr*( Prfc + Padc) + Pbb;   % receiver side
EE_D = R_D./(Pdt + Pdr);

for i = 1:length(Nrf)
                

% Energy efficiency computation for full connected phased array
Ppst =  Nt*Nrf(i)*Pps + Nrf(i)*(Prfc + Padc) + Pbb; % tranmitter side
Ppsr =  Nr*Nrf(i)*Pps + Nrf(i)*(Prfc + Padc) + Pbb; % receiver side
EE_PS(i) = R_PS(i)/(Ppst + Ppsr);
EE_MoAlt(i) = R_MoAlt(i)/(Ppst + Ppsr);

% Energy efficiency computation for PI at the transmitter and phase shifter
% at the receiver
PIt =  2*Nrf(i)*Pps + Nrf(i)*(2*Nt - 2)*PVGA + Nrf(i)*(Prfc + Padc) + Pbb;  % tranmitter side
PIr =  2*Nrf(i)*Pps + Nrf(i)*(2*Nr - 2)*PVGA + Nrf(i)*(Prfc + Padc) + Pbb; % receiver side
EE_PI(i) = R_PI(i)/(PIt + PIr);

end

end  % end of the function