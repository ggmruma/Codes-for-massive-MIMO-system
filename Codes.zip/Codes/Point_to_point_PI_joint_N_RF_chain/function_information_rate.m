% cost function
function Rate = function_information_rate(H, P, Ns, FRF, WRFO)

 %Rate = log2(det(eye(Ns) + P/Ns * pinv(W) * H * (F)* F' * H' * W));
 
 %He = H*FRFO;
 %FBB = inv(He'*He);
 %FBBO = (1/0.5*(norm(FBB,'fro')))*FBB;4
 % determining the dimension of FRFO
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 [~, Nrf] = size(FRF);
 switch Nrf
    case 2
        n = 1.7;
    case 3
        n = 1.77;
    case 4
        n = 1.77;
    otherwise
        n = 1.74;
end
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

 if Ns == Nrf
    alpha = 1 + (n-1)*rand(1);
    FRFO = alpha.*FRF;
    %FRFO = FRF;
 else
    alpha = 1 + (n - 1)*rand(1);
    FRFO = alpha.*FRF;
 end
 %He = H*FRFO;
 %[~,~,V] = svd(He);
 %FBBO = V(1:Nrf,1:Ns);
 %FBBO = eye(Nrf,Ns);
 % alpha = 1 + (2-1)*rand(1);
 % FBBO = alpha*eye(Ns);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % From the paper
 He = H*FRFO;
 Q = FRFO'*FRFO;
 T = He*(Q)^(-0.5);
 kk = isnan(T);
 ll = sum(find(kk));
 if ll > 0
    [~,~,V1] = svd(He);
    U1 = V1(:,1:Ns);
    FBB = (Q)^(-0.5)*U1*sqrt(Ns);
    FBBO = FBB/norm(FRF*FBB,'fro');
 else
     
    [~,~,V1] = svd(He*(Q)^(-0.5));
    U1 = V1(:,1:Ns);
    FBB = (Q)^(-0.5)*U1*sqrt(Ns);
    FBBO = FBB/norm(FRF*FBB,'fro');
 end
 
 
 
 %Her = WRFO'*He;
 %WBBO = pinv(Her'*Her);
 %alpha = norm(H,'fro');
 FT = FRFO*FBBO;
 J = (WRFO)'*H*(FT)*(FT)'*H'*WRFO + P*(WRFO)'*WRFO;
 WBBO = inv(J)*WRFO'*H*FT;
 
 sss = isnan(WBBO);
 s1 = sum(find(sss));
 if s1 > 0
     WBBO = eye(Ns);
 end
 
 Rate = log2(det(eye(Ns) + P/Ns * pinv(WRFO * WBBO) * H * FRFO * (FBBO) * FBBO' * FRFO' * H' * WRFO * WBBO));

end